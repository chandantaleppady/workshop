I'll provide detailed steps for creating AWS RDS and S3 resources for your application. Let me break this down into a comprehensive guide. # Comprehensive Guide: Setting Up AWS RDS and S3 for StudentRegistryApp

## Table of Contents
1. AWS Account Setup
2. AWS CLI Configuration
3. Creating an RDS SQL Server Instance
4. Creating an S3 Bucket
5. Configuring IAM Permissions
6. Updating Application Configuration
7. Testing the Application
8. Troubleshooting

## 1. AWS Account Setup

If you don't already have an AWS account:

1. Visit [https://aws.amazon.com/](https://aws.amazon.com/)
2. Click "Create an AWS Account"
3. Follow the registration process, providing:
   - Email address
   - Password
   - AWS account name
4. Provide payment information (AWS has a free tier, but a credit card is required)
5. Complete identity verification (usually via phone)
6. Choose a support plan (the free Basic Support is sufficient for starting)

## 2. AWS CLI Configuration

### Install AWS CLI

1. **Windows**: 
   ```powershell
   # Download the installer
   Invoke-WebRequest -Uri "https://awscli.amazonaws.com/AWSCLIV2.msi" -OutFile "AWSCLIV2.msi"
   
   # Install
   Start-Process -FilePath msiexec.exe -Args "/i AWSCLIV2.msi /quiet" -Wait
   ```

2. **Verify installation**:
   ```powershell
   aws --version
   ```

### Create IAM User with Programmatic Access

1. Sign in to the [AWS Management Console](https://console.aws.amazon.com/)
2. Navigate to IAM (Identity and Access Management)
3. Click "Users" → "Add users"
4. Enter a username (e.g., "studentapp-admin")
5. Select "Access key - Programmatic access"
6. Click "Next: Permissions"
7. Click "Attach existing policies directly"
8. Search for and select:
   - "AmazonRDSFullAccess"
   - "AmazonS3FullAccess"
9. Click "Next: Tags" (optional)
10. Click "Next: Review"
11. Click "Create user"
12. **IMPORTANT**: Download the CSV file with access key and secret key or copy them securely

### Configure AWS CLI

```powershell
aws configure
```

Enter the following information:
- AWS Access Key ID: [Your access key]
- AWS Secret Access Key: [Your secret key]
- Default region name: eu-north-1 (or your preferred region)
- Default output format: json

## 3. Creating an RDS SQL Server Instance

### Using AWS Management Console:

1. Sign in to the [AWS Management Console](https://console.aws.amazon.com/)
2. Navigate to RDS service
3. Click "Create database"
4. Select "Standard create"
5. Choose "Microsoft SQL Server" as engine type
6. Select "SQL Server Express Edition" (for development) or "SQL Server Standard Edition" (for production)
7. Choose SQL Server version (SQL Server 2019 or newer is recommended for .NET 8)
8. Choose "Dev/Test" or "Production" template
9. Configure settings:
   - **DB instance identifier**: `student-registry-db`
   - **Master username**: `admin` (or your preferred username)
   - **Master password**: Create a strong password
10. Choose instance configuration:
    - **DB instance class**: db.t3.micro (free tier) or larger as needed
    - **Storage**: General Purpose SSD (gp2), 20GB minimum
11. Configure connectivity:
    - **Virtual Private Cloud (VPC)**: Default VPC
    - **Publicly accessible**: Yes (for development, No for production)
    - **VPC Security group**: Create new or select existing
    - **Availability Zone**: No preference
12. Additional configuration:
    - **Initial database name**: `students`
    - **Backup retention period**: 7 days (or as needed)
    - **Enable encryption**: Yes (recommended)
13. Click "Create database"

### Security Group Configuration:

After your RDS instance is creating, you need to configure the security group:

1. Go to the RDS dashboard
2. Click on your new DB instance
3. Under "Connectivity & security", note the VPC security group
4. Click the security group link
5. Go to "Inbound rules" tab
6. Click "Edit inbound rules"
7. Add a rule:
   - Type: MS SQL
   - Protocol: TCP
   - Port range: 1433
   - Source: Your IP address (for development), or your application server IP
8. Click "Save rules"

### Get Connection String Information:

1. Go to the RDS dashboard
2. Click on your DB instance
3. Under "Connectivity & security", note:
   - Endpoint
   - Port
4. Use these values to create your connection string:
   ```
   Server=endpoint;Initial Catalog=students;User ID=admin;Password=your-password;TrustServerCertificate=True;MultipleActiveResultSets=True;
   ```

## 4. Creating an S3 Bucket

### Using AWS Management Console:

1. Sign in to the [AWS Management Console](https://console.aws.amazon.com/)
2. Navigate to S3 service
3. Click "Create bucket"
4. Basic configuration:
   - **Bucket name**: `student-registry-images-[unique-suffix]` (must be globally unique)
   - **AWS Region**: Choose the same region as your RDS instance
5. Configure options:
   - **Block all public access**: Enable (recommended for security)
   - **Bucket versioning**: Disable (unless needed)
   - **Default encryption**: Enable (using Amazon S3-managed keys)
6. Click "Create bucket"

### Configure CORS (if needed):

1. Go to your new bucket
2. Click "Permissions" tab
3. Scroll down to "Cross-origin resource sharing (CORS)"
4. Click "Edit"
5. Paste the following configuration:
   ```json
   [
     {
       "AllowedHeaders": ["*"],
       "AllowedMethods": ["GET", "PUT", "POST", "DELETE"],
       "AllowedOrigins": ["*"],
       "ExposeHeaders": []
     }
   ]
   ```
   (Note: For production, replace `"*"` in `AllowedOrigins` with your specific domains)
6. Click "Save changes"

## 5. Configuring IAM Permissions

### Creating a Dedicated IAM User for the Application:

1. Navigate to IAM service
2. Click "Users" → "Add users"
3. Enter a username (e.g., "studentapp-service")
4. Select "Access key - Programmatic access"
5. Click "Next: Permissions"
6. Click "Create group"
7. Name the group (e.g., "StudentAppServices")
8. Add the following policies:
   - Create a custom policy for RDS:
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [
         {
           "Effect": "Allow",
           "Action": [
             "rds:DescribeDBInstances",
             "rds:ConnectToDatabase"
           ],
           "Resource": "arn:aws:rds:*:*:db:student-registry-db"
         }
       ]
     }
     ```
   - Create a custom policy for S3:
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [
         {
           "Effect": "Allow",
           "Action": [
             "s3:GetObject",
             "s3:PutObject",
             "s3:DeleteObject",
             "s3:ListBucket"
           ],
           "Resource": [
             "arn:aws:s3:::your-bucket-name",
             "arn:aws:s3:::your-bucket-name/*"
           ]
         }
       ]
     }
     ```
9. Select the newly created group
10. Click "Next: Tags" → "Next: Review" → "Create user"
11. **IMPORTANT**: Download the CSV file with access key and secret key

## 6. Updating Application Configuration

Update your appsettings.json with the AWS configuration details:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  
  "CloudConfig": {
    "Provider": "AWS"
  },
  
  "ConnectionStrings": {
    "AwsRds": "Server=your-rds-endpoint.region.rds.amazonaws.com;Initial Catalog=students;User ID=admin;Password=your-password;TrustServerCertificate=True;MultipleActiveResultSets=True;"
  },
  
  "S3Configs": {
    "AccessKey": "YOUR_AWS_ACCESS_KEY",
    "SecretKey": "YOUR_AWS_SECRET_KEY",
    "Region": "eu-north-1",
    "BucketName": "student-registry-images-unique-suffix"
  }
}
```

## 7. Testing the Application

### Database Migration:

Since we've set up a new database, we need to apply migrations:

1. Update the connection string in `appsettings.Development.json` (for local testing)
2. Run Entity Framework migrations to create the database schema:
   ```powershell
   dotnet ef database update
   ```

### Local Testing:

1. Run the application locally:
   ```powershell
   dotnet run
   ```
2. Test all functionality that uses database and blob storage
3. Check logs for any AWS-related errors

### Deploy to AWS Elastic Beanstalk:

If you're using AWS Elastic Beanstalk for deployment:

1. Build your application:
   ```powershell
   .\deploy.ps1
   ```
2. Upload the deployment package to Elastic Beanstalk

## 8. Troubleshooting

### Common RDS Issues:

1. **Connection Timeout**: Check security groups to ensure your application's IP is allowed
2. **Authentication Failed**: Verify username and password in connection string
3. **Database Not Found**: Ensure the database name exists in RDS

### Common S3 Issues:

1. **Access Denied**: Check IAM permissions and ensure access keys are correct
2. **Region Issues**: Ensure the region in your code matches the S3 bucket region
3. **CORS Errors**: Verify CORS configuration if accessing S3 directly from a browser

### Viewing AWS Logs:

1. **For RDS**:
   - Go to RDS console → Databases → your-db-instance
   - Click "Logs & events" tab
   - View available logs

2. **For S3**:
   - Enable S3 access logging in bucket properties
   - View access logs in the designated logging bucket

3. **For Application**:
   - Set up CloudWatch Logs for your application
   - Configure application to use AWS CloudWatch logging

## Cost Management

### Monitoring Costs:

1. Set up AWS Budgets to track spending
2. Use the AWS Cost Explorer to analyze costs
3. Consider using Reserved Instances for RDS if planning long-term use

### Cost-Saving Tips:

1. Use RDS instance types in the free tier for development
2. Stop RDS instances when not in use
3. Configure S3 lifecycle rules to transition infrequently accessed data to cheaper storage classes

## Security Best Practices

1. Never commit AWS credentials to source control
2. Regularly rotate access keys
3. Use AWS Secrets Manager for managing sensitive credentials
4. Enable MFA for your AWS account
5. Follow the principle of least privilege when assigning IAM permissions
6. Enable encryption for RDS and S3
7. Set up VPC endpoints for private communication between services

---

By following this comprehensive guide, you should be able to successfully set up AWS RDS and S3 for your StudentRegistryApp and configure your application to use these AWS services instead of Azure.

Remember to clean up resources when you're done experimenting to avoid unnecessary charges to your AWS account.

Similar code found with 2 license types