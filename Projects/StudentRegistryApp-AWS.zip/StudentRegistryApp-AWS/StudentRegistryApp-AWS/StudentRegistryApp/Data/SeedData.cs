using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using UtilsLib.Context;
using UtilsLib.Models;

namespace StudentRegistryApp.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

            // Check if there are already students in the database
            if (await context.Students.AnyAsync())
            {
                return; // Database already has data
            }

            // Add sample students
            await context.Students.AddRangeAsync(
                new Student
                {
                    Name = "John Doe",
                    Age = 21,
                    Email = "john.doe@example.com"
                },
                new Student
                {
                    Name = "Jane Smith",
                    Age = 22,
                    Email = "jane.smith@example.com"
                },
                new Student
                {
                    Name = "Bob Johnson",
                    Age = 20,
                    Email = "bob.johnson@example.com"
                }
            );

            await context.SaveChangesAsync();
        }
    }
}
