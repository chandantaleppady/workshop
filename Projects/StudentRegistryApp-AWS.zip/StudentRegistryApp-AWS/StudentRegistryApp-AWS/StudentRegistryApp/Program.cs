using System;
using Microsoft.EntityFrameworkCore;
using UtilsLib.Configs;
using UtilsLib.Context;
using UtilsLib.Repositories;
using UtilsLib.Tools;
using Microsoft.Extensions.Logging;

public class Program
{
    public static async Task Main(string[] args)
    {
        IConfiguration configuration = new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddEnvironmentVariables()
    .Build();

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
ConfigureServices(builder.Services, configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Student}/{action=Index}/{id?}");

// Seed the database
try
{
    await StudentRegistryApp.Data.SeedData.Initialize(app.Services);
    var logger = app.Services.GetRequiredService<ILogger<Program>>();
    logger.LogInformation("Database seeding completed successfully.");
}
catch (Exception ex)
{
    var logger = app.Services.GetRequiredService<ILogger<Program>>();
    logger.LogError(ex, "An error occurred while seeding the database.");
}

app.Run();

static void ConfigureServices(IServiceCollection services, IConfiguration configuration)
{
    // Configure cloud settings
    services.Configure<CloudConfig>(configuration.GetSection("CloudConfig"));
    var cloudConfig = configuration.GetSection("CloudConfig").Get<CloudConfig>() ?? new CloudConfig();

    // Configure database based on provider
    if (cloudConfig.Provider == CloudProvider.AWS)
    {
        services.AddDbContextPool<AppDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("AwsRds"), 
                sqlServerOptions => {
                    sqlServerOptions.MigrationsAssembly("StudentRegistryApp");
                    sqlServerOptions.EnableRetryOnFailure(
                        maxRetryCount: 5, 
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                    sqlServerOptions.CommandTimeout(30);
                }));
    }
    else // Default to Azure
    {
        services.AddDbContextPool<AppDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("EmployeeDb"), 
                sqlServerOptions => {
                    sqlServerOptions.MigrationsAssembly("StudentRegistryApp");
                    sqlServerOptions.EnableRetryOnFailure(
                        maxRetryCount: 5, 
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                    sqlServerOptions.CommandTimeout(30);
                }));
    }

    // Configure blob storage
    services.Configure<BlobConfigs>(configuration.GetSection("BlobConfigs"));
    services.Configure<S3Configs>(configuration.GetSection("S3Configs"));
    services.AddOptions();

    services
        .AddTransient<IStudentsRepository, StudentsRepository>()
        .AddTransient<IDataUploadUtil, DataUploadUtil>();

    // Register blob utils using factory pattern
    services.AddTransient<BlobUtilsFactory>();
    services.AddTransient<IBlobUtils>(provider =>
    {
        var factory = provider.GetRequiredService<BlobUtilsFactory>();
        return factory.CreateBlobUtils();
    });
}
    }
}