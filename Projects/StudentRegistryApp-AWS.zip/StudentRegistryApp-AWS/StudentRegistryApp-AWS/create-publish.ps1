$publishDir = "publish"
$zipFile = "deploy.zip"

dotnet publish -c Release -r linux-x64 -o $publishDir

if ($LASTEXITCODE -ne 0) {
    Write-Host "Publish failed. Exiting."
    exit 1
}

Compress-Archive -Path "$publishDir\*" -DestinationPath $zipFile -Force

Write-Host "Deployment package created: $zipFile"