namespace UtilsLib.Configs
{
    /// <summary>
    /// Defines the available cloud providers for the application.
    /// </summary>
    public enum CloudProvider
    {
        /// <summary>
        /// Microsoft Azure cloud provider.
        /// </summary>
        Azure,
        
        /// <summary>
        /// Amazon Web Services (AWS) cloud provider.
        /// </summary>
        AWS
    }
}
