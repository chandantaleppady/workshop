namespace UtilsLib.Configs
{
    /// <summary>
    /// Contains configuration settings for the cloud provider.
    /// </summary>
    public class CloudConfig
    {
        /// <summary>
        /// Gets or sets the cloud provider to use for the application.
        /// </summary>
        public CloudProvider Provider { get; set; } = CloudProvider.Azure;
    }
}
