namespace UtilsLib.Configs
{
    /// <summary>
    /// Represents configuration settings for connecting to AWS RDS database service.
    /// </summary>
    public class RdsConfigs
    {
        /// <summary>
        /// Gets or sets the connection string for the AWS RDS database.
        /// </summary>
        public string ConnectionString { get; set; }
    }
}
