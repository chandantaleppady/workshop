namespace UtilsLib.Configs
{
    /// <summary>
    /// Represents configuration settings for connecting to AWS S3 storage service.
    /// </summary>
    public class S3Configs
    {
        /// <summary>
        /// Gets or sets the AWS access key.
        /// </summary>
        public string AccessKey { get; set; }

        /// <summary>
        /// Gets or sets the AWS secret key.
        /// </summary>
        public string SecretKey { get; set; }

        /// <summary>
        /// Gets or sets the AWS region for the S3 bucket.
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Contains the name of the S3 bucket where files will be stored.
        /// </summary>
        public string BucketName { get; set; }
    }
}
