using Microsoft.Extensions.Options;
using UtilsLib.Configs;

namespace UtilsLib.Tools
{
    /// <summary>
    /// Factory for creating the appropriate blob storage utility based on configuration.
    /// </summary>
    public class BlobUtilsFactory
    {
        private readonly IOptions<CloudConfig> _cloudConfig;
        private readonly IOptions<BlobConfigs> _blobConfigs;
        private readonly IOptions<S3Configs> _s3Configs;

        /// <summary>
        /// Initializes a new instance of the <see cref="BlobUtilsFactory"/> class.
        /// </summary>
        /// <param name="cloudConfig">The cloud provider configuration.</param>
        /// <param name="blobConfigs">The Azure blob storage configuration.</param>
        /// <param name="s3Configs">The AWS S3 configuration.</param>
        public BlobUtilsFactory(
            IOptions<CloudConfig> cloudConfig,
            IOptions<BlobConfigs> blobConfigs,
            IOptions<S3Configs> s3Configs)
        {
            _cloudConfig = cloudConfig;
            _blobConfigs = blobConfigs;
            _s3Configs = s3Configs;
        }

        /// <summary>
        /// Creates and returns the appropriate IBlobUtils implementation based on configuration.
        /// </summary>
        /// <returns>An implementation of IBlobUtils.</returns>
        public IBlobUtils CreateBlobUtils()
        {
            return _cloudConfig.Value.Provider switch
            {
                CloudProvider.Azure => new BlobUtils(_blobConfigs),
                CloudProvider.AWS => new S3BlobUtils(_s3Configs),
                _ => new BlobUtils(_blobConfigs) // Default to Azure
            };
        }
    }
}
