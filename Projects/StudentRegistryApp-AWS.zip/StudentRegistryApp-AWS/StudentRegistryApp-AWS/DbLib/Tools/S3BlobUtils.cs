using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using System.Text;
using System.Linq;
using UtilsLib.Configs;

namespace UtilsLib.Tools
{
    /// <summary>
    /// Provides utility methods for interacting with AWS S3 Storage.
    /// </summary>
    public class S3BlobUtils : IBlobUtils
    {
        private readonly S3Configs _s3Configs;
        private readonly IAmazonS3 _s3Client;

        /// <summary>
        /// Initializes a new instance of the <see cref="S3BlobUtils"/> class with the specified S3 configuration options.
        /// </summary>
        /// <param name="s3Configs">The S3 storage configuration options.</param>
        public S3BlobUtils(IOptions<S3Configs> s3Configs)
        {
            _s3Configs = s3Configs.Value;
            
            // Create an S3 client
            var region = RegionEndpoint.GetBySystemName(_s3Configs.Region);
            _s3Client = new AmazonS3Client(_s3Configs.AccessKey, _s3Configs.SecretKey, region);
        }

        /// <summary>
        /// Exception that occurred during the last operation, if any.
        /// </summary>
        public Exception LastException { get; private set; }

        /// <summary>
        /// Gets the error message from the last failed operation, if any.
        /// </summary>
        public string LastErrorMessage => LastException?.Message;
        
        /// <summary>
        /// Uploads the specified content to an object in the S3 bucket.
        /// </summary>
        /// <param name="content">The content to upload, represented as a <see cref="StringBuilder"/>.</param>
        /// <param name="filePath">The path/key of the file to upload within S3.</param>
        /// <returns>
        /// A task representing the asynchronous operation, with a result indicating <c>true</c> if the upload was successful; otherwise, <c>false</c>.
        /// </returns>

        public async Task<bool> UploadFileAsync(StringBuilder content, string filePath)
        {
            try
            {
                LastException = null;
                
                // Ensure the bucket exists
                var listBucketsResponse = await _s3Client.ListBucketsAsync();
                bool bucketExists = listBucketsResponse.Buckets.Any(b => b.BucketName == _s3Configs.BucketName);
                
                if (!bucketExists)
                {
                    try
                    {
                        var createBucketRequest = new PutBucketRequest
                        {
                            BucketName = _s3Configs.BucketName,
                            UseClientRegion = true
                        };
                        await _s3Client.PutBucketAsync(createBucketRequest);
                    }
                    catch (AmazonS3Exception ex) when (ex.ErrorCode == "BucketAlreadyExists" || ex.ErrorCode == "BucketAlreadyOwnedByYou")
                    {
                        // This is fine, someone else created the bucket with this name or we already own it
                        bucketExists = true;
                    }
                    catch (AmazonS3Exception ex)
                    {
                        // Handle specific bucket creation errors
                        LastException = ex;
                        Console.WriteLine($"S3 Bucket Creation Error: {ex.Message}, Error Code: {ex.ErrorCode}");
                        return false;
                    }
                }

                // Upload the file
                var contentBytes = Encoding.UTF8.GetBytes(content.ToString());
                using var stream = new MemoryStream(contentBytes);
                
                var putRequest = new PutObjectRequest
                {
                    BucketName = _s3Configs.BucketName,
                    Key = filePath,
                    InputStream = stream,
                    ContentType = "text/plain"
                };

                await _s3Client.PutObjectAsync(putRequest);
                return true;
            }
            catch (Exception ex)
            {
                // Store and log exception details
                LastException = ex;
                Console.WriteLine($"S3 Error: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                return false;
            }
        }
    }
}
