# Student Registry App - Multi-Cloud Support

This application now supports both Azure and AWS cloud services for blob storage and database operations.

## Cloud Providers

The application can be configured to use either:
- **Azure** - Using Azure SQL Database and Azure Blob Storage
- **AWS** - Using Amazon RDS and Amazon S3

## Configuration

### Setting the Cloud Provider

In the `appsettings.json` file, set the cloud provider:

```json
"CloudConfig": {
  "Provider": "Azure"  // Use "Azure" or "AWS"
}
```

### Azure Configuration (Default)

```json
"ConnectionStrings": {
  "EmployeeDb": "Server=tcp:your-azure-server.database.windows.net,1433;Initial Catalog=your-db;..."
},
"BlobConfigs": {
  "ConnectionString": "DefaultEndpointsProtocol=https;AccountName=youraccount;...",
  "ContainerName": "studentimages"
}
```

### AWS Configuration

```json
"ConnectionStrings": {
  "AwsRds": "Server=your-rds-instance.amazonaws.com;Initial Catalog=students;..."
},
"S3Configs": {
  "AccessKey": "YOUR_AWS_ACCESS_KEY",
  "SecretKey": "YOUR_AWS_SECRET_KEY",
  "Region": "eu-north-1",
  "BucketName": "student-images"
}
```

## How It Works

The application uses a factory pattern to create the appropriate implementation based on the configured provider:

1. **Database Access**:
   - Azure: Uses SQL Server on Azure
   - AWS: Uses Amazon RDS (SQL Server)

2. **Blob Storage**:
   - Azure: Uses Azure Blob Storage via `BlobUtils`
   - AWS: Uses Amazon S3 via `S3BlobUtils`

## Required Packages

- For Azure:
  - Azure.Storage.Blobs
  - Microsoft.EntityFrameworkCore.SqlServer

- For AWS:
  - AWSSDK.S3
  - AWSSDK.Extensions.NETCore.Setup
  - AWSSDK.Core
  - Microsoft.EntityFrameworkCore.SqlServer (still used for RDS)

## Switching Between Providers

Simply update the `CloudConfig.Provider` setting in `appsettings.json` and restart the application.

## Development

To extend this functionality:

1. Create new interfaces for services that need cloud-specific implementations
2. Create implementations for both Azure and AWS
3. Create factories to return the appropriate implementation based on configuration
4. Update dependency injection in Program.cs
